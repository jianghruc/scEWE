addpath('.\Matlab')
main('Biase',1,0.5,0,1,1,1,1,1,10,5,'C:\Program Files\R\R-4.3.2\bin\x64\Rscript.exe');
