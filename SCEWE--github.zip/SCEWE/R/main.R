main=function(dataname,SHARP=TRUE,SIMLR=TRUE,CIDR=TRUE,SC3=TRUE,Seurat=TRUE,k,d=10,Seed=5)
{
#Load packages
library(SHARP)
library(SIMLR)
library(cidr)
library(SingleCellExperiment)
library(SC3)
library(Seurat)

#Load datasets
setwd('./RawData')
data=read.table(paste0(as.character(dataname),".csv"),sep=",");
n=dim(data)[2];
q=dim(data)[1]-1;
labels=as.matrix(data[q+1,]);
fea=as.matrix(data[1:q,]);

setwd('../R')

#Generate base clustering
source('PreEnsemble.R')
enresult=PreEnsemble(fea,labels,SHARP,SIMLR,CIDR,SC3,Seurat,k,d,Seed);

#save results
setwd('../')
if(file.exists('BCResults')){
   setwd('./BCResults')
}else{dir.create('BCResults')
      setwd('./BCResults')
}
write.table(enresult,paste0("BCResults_",as.character(dataname),".csv"),row.names=FALSE,col.names=FALSE,sep=",")

}
args <- commandArgs(trailingOnly = TRUE)
dataname<-args[1]
SHARP<-as.logical(as.numeric(args[2]))
SIMLR<-as.logical(as.numeric(args[3]))
CIDR<-as.logical(as.numeric(args[4]))
SC3<-as.logical(as.numeric(args[5]))
Seurat<-as.logical(as.numeric(args[6]))
k<-as.numeric(args[7])
d<-as.numeric(args[8])
Seed<-as.numeric(args[9])
main(dataname,SHARP,SIMLR,CIDR,SC3,Seurat,k,d,Seed)



