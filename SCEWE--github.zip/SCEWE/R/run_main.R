main=function(dataname,SHARP=TRUE,SIMLR=TRUE,CIDR=TRUE,SC3=TRUE,Seurat=TRUE,k,d=10,Seed=5)
{
#Load packages
library(SHARP)
library(SIMLR)
library(cidr)
library(SingleCellExperiment)
library(SC3)
library(Seurat)

#Load datasets
setwd('./RawData')
data=read.table(paste0(as.character(dataname),".csv"),sep=",");
n=dim(data)[2];
q=dim(data)[1]-1;
labels=as.matrix(data[q+1,]);
fea=as.matrix(data[1:q,]);

setwd('../R')

#Generate base clustering
source('PreEnsemble.R')
enresult=PreEnsemble(fea,labels,SHARP,SIMLR,CIDR,SC3,Seurat,k,d,Seed);

#Save results
setwd('../')
if(file.exists('BCResults')){
   setwd('./BCResults')
}else{dir.create('BCResults')
      setwd('./BCResults')
}
write.table(enresult,paste0("BCResults_",as.character(dataname),".csv"),row.names=FALSE,col.names=FALSE,sep=",")

}
main("Biase",1,1,1,1,1,3,10,5)

