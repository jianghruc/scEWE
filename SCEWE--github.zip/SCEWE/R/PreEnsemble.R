PreEnsemble=function(fea,labels,SHARP,SIMLR,CIDR,SC3,Seurat,k,d,Seed)
{
library(dplyr)

n=dim(fea)[2];
m=dim(fea)[1];
resultSHARP=resultSIMLR=resultCIDR=resultSC3=resultSeurat=matrix(0,n,d)

v=apply(fea,1,var);
for (i in 1:d)
{
#Select hypervariable gene
rank=order(v,decreasing=TRUE)[1:(i*10+round(m/10)-d*5)];
fea1=fea[rank,];

#SHARP method
if(SHARP)
{
capt1=capture.output(resultSHARP[,i]<-SHARP(fea1,N.cluster=k,rN.seed=Seed)$pred_clusters);
message("Preprocessing of SHARP, Round ",i, ", Time: ",Sys.time())
}
#SIMLR method
if(SIMLR)
{
capt2=capture.output(resultSIMLR[,i]<-SIMLR(X=fea1,c=k)$y$cluster);
message("Preprocessing of (SIMLR, Round ",i, ", Time: ",Sys.time())
}
#CIDR method
if(CIDR)
{
methodCIDR=scDataConstructor(fea1)%>%
determineDropoutCandidates()%>%
wThreshold()%>%
scDissim()%>%
scPCA()%>%
nPC()%>%
scCluster(nCluster=k);
resultCIDR[,i]=methodCIDR@clusters
message("Preprocessing of CIDR, Round ",i, ", Time: ",Sys.time())
}
#SC3 method
if(SC3)
{
set.seed(Seed)
methodSC3=SingleCellExperiment(assays=list(counts=fea1,logcounts=log2(fea1+1)));
rowData(methodSC3)$feature_symbol=rownames(methodSC3);
capt3=capture.output(suppressMessages(methodSC3<-sc3(methodSC3,ks=k,svm_max=n,gene_filter=FALSE)));
sc3_truek_clusters=paste0("sc3_", as.character(k),"_clusters")
resultSC3[,i]=as.numeric(colData(methodSC3)[[sc3_truek_clusters, exact = FALSE]]);
message("Preprocessing of SC3, Round ",i, ", Time: ",Sys.time())

}
#Seurat method
if(Seurat)
{
methodSeurat<-CreateSeuratObject(fea1)%>%
NormalizeData(normalization.method = "LogNormalize", scale.factor = 10000,verbose=FALSE)%>%
FindVariableFeatures(selection.method="vst",nfeatures=1000,verbose=FALSE)%>%
ScaleData(verbose=FALSE);
suppressWarnings(methodSeurat<-RunPCA(npcs=40,object=methodSeurat,features=VariableFeatures(methodSeurat),verbose=FALSE)%>%
FindNeighbors(dims=1:10,verbose=FALSE)%>%
FindClusters(resolution=1.5,verbose=FALSE));
resultSeurat[,i]=as.numeric(Idents(methodSeurat));
message("Preprocessing of Seurat, Round ",i, ", Time: ",Sys.time())
}
message("Preprocessing of ",length(rank)," hypervariable genes is complete.")
}

#Show results
results=cbind(resultSHARP,resultSIMLR,resultCIDR,resultSC3,resultSeurat,t(labels));
results=results[,colSums(results^2)!=0]

message("The preprocessing is complete.")
return(results)
}
