function [ARI,NMI]=main_largescale(dataname,highorder,gamma,GeneratePool,SHARP,SIMLR,CIDR,SC3,Seurat,d,Seed,RscriptPath)
addpath('./RawData')
addpath('./Matlab')
%Load data
dataname=char(dataname);
rawdata=load([dataname,'.csv']);
data=rawdata(1:(end-1),:)';
gt=rawdata(end,:);
tic
kpre=length(unique(gt));
%Generate base clustering pools
if GeneratePool==1
GeneratePools(RscriptPath,dataname,SHARP,SIMLR,CIDR,SC3,Seurat,kpre,d,Seed)
end
%Load base clustering results
addpath('./BCResults')
pools=load(['BCResults_',dataname,'.csv']);
pools=pools(:,1:end-1);
%Set parameters
mu=1e-3;
tau=1000;
if exist('gamma','var')==0
gamma=0.5;
end
%self-adapt determine lambda
[lambda,poolsget]=DetermineLambda(dataname,data,kpre,pools,highorder,1);
%Perform ensemble and get the consensus matrix
s=cell(1,51);
S=cell(1,51);
w=cell(1,51);
[s{1},S{1}]=WeightingCAMatrix(poolsget,gamma);
for i=1:1
w{i}=GeneratingWeights_largescale(poolsget,S{i},tau,highorder,lambda,10);
[s{i+1},S{i+1}]=WeightingCAMatrix(poolsget,gamma,s{i},w{i});
if norm(S{i+1}-S{i},'fro')/norm(S{i},'fro')<mu
break
end
end
S(cellfun(@isempty,S))=[];
%Spectral ensemble clustering
%label=SpectralEnsemble(cell2mat(S(end)),kpre,1000,100);
label=EA(cell2mat(S(end)),kpre);
ARI=ari(gt,label);
NMI=nmi(gt,label);
%Show reults
disp('#############Scores#############')
disp(['ARI: ',num2str(ARI)])
disp(['NMI: ',num2str(NMI)])

toc
save(['.\Enresults\EnResult_',dataname,'.mat'],'label');