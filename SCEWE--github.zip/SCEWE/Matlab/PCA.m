function z = PCA(a,lambda)
proporition = lambda;
[coeff,~,latent] = pca(a);
sum_latent = cumsum(latent/sum(latent));  % 累计贡献率
dimension = find(sum_latent>proporition);
dimension = dimension(1);
z = a*coeff(:,1:dimension);