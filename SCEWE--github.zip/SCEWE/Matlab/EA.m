function label=EA(W,nClass)
W=1-W;
y=squareform(W);
Z=linkage(y,'average');
K=nClass;
label=cluster(Z,'maxclust',K);
end