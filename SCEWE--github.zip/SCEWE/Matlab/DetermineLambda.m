function [lambdapre,poolsget]=DetermineLambda(dataname,data,kpre,pools,highorder,largescale)
[n,q]=size(data);
%Set parameters
mu=1e-3;
if n>=400
    tau=floor(n*(2000+extractdata(relu(dlarray(q-15000,"SSCB"))))/(3600*(kpre+1)));
    else
    tau=floor(n*(2000+extractdata(relu(dlarray(q-15000,"SSCB"))))/(10000*(kpre+1)));
end
gamma=0.5;
if largescale == 0
    %Variance analysis prepocessing
    nClass=9;
    stdX=std(data);
    [~,sind]=sort(-stdX);
    k=1;
    
    Xstar=data(:,sind(1:k));
    ratio=zeros(nClass,k);
    
    for i=1:nClass
    lambda=i/10;
    poolsget=pools;
    
    %Perform ensemble and get the consensus matrix
    s=cell(1,51);
    S=cell(1,51);
    w=cell(1,51);
    [s{1},S{1}]=WeightingCAMatrix(poolsget,gamma);
    
    %Generate co-association matrix
    for iter=1:10
    w{iter}=GeneratingWeights(poolsget,S{iter},tau,highorder,lambda);
    [s{iter+1},S{iter+1}]=WeightingCAMatrix(poolsget,gamma,s{iter},w{iter});
    if norm(S{iter+1}-S{iter},'fro')/norm(S{iter},'fro')<mu
    break
    end
    end
    S(cellfun(@isempty,S))=[];
    
    %Clusteirng
    labelnew=EA(cell2mat(S(end)),kpre);
    
    %Varianve analysis
    for j=1:k
    [~,tbl]=anova1(Xstar(:,j),labelnew,'off');
    ratio(i,j)=(tbl{2,2}/tbl{2,3})/(tbl{4,2}/tbl{4,3});
    end
    end
    ratiostar=sum(ratio,2);
    [~,lambdapre]=max(ratiostar(1:end,1));
    lambdapre=lambdapre/10;
    poolsget=SelectBaseClustering(pools,gamma,tau,highorder,lambdapre);
else 
    lambdapre=0.5;
    tau=1000;
    poolsget=SelectBaseClustering_largescale(dataname,pools,gamma,tau);
end


