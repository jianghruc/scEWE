function GeneratePools(RscriptPath,dataname,SHARP,SIMLR,CIDR,SC3,Seurat,kpre,d,Seed)
%Generate base clustering pools
RscriptPath=char(RscriptPath);
[a,b]=system(['"',RscriptPath,'" "./R/main.R" ', '"',dataname,'" ' ...
    ,num2str(SHARP),' ',num2str(SIMLR),' ',num2str(CIDR),' ',num2str(SC3),' ',num2str(Seurat),' ', ...
    num2str(kpre),' ',num2str(d),' ',num2str(Seed)]);
if a==0
    disp('Success to generate base clustering pools')
else 
    disp('Exist errors in generating base clustering pools.')
    disp('###########################################################')
    disp(b)
end