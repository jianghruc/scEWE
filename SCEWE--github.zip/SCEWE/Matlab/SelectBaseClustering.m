function poolsget=SelectBaseClustering(pools,gamma,tau,highorder,lambda)
%Select base clustering
mu=1e-3;
if highorder == 1
    s=cell(1,51);
    S=cell(1,51);
    w=cell(1,51);
    [s{1},S{1}]=WeightingCAMatrix(pools,gamma);
    for i=1:50
    w{i}=GeneratingWeights(pools,S{i},tau,highorder,lambda);
    [s{i+1},S{i+1}]=WeightingCAMatrix(pools,gamma,s{i},w{i});
    if norm(S{i+1}-S{i},'fro')/norm(S{i},'fro')<mu
    break
    end
    end
    S(cellfun(@isempty,S))=[];
    w(cellfun(@isempty,w))=[];
    W=sum(cell2mat(w(end)));
    [~,index1]=sort(W,'descend');
    poolsget=pools(:,index1(1:5));
else
    poolsget=pools;
end
