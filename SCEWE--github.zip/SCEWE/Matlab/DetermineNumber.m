function kpre=DetermineNumber(data)
%Determine the clustering number
[n,q]=size(data);
nClass=16;
stdX=std(data);
[~,sind]=sort(-stdX);
c=15;
if n > 400
k=ceil(sqrt(n /c) * log(1000 + extractdata(relu(dlarray(q - 8000,"SSCB")))));
else
k =ceil(sqrt(n / (2 * c)) * log(1000 + extractdata(relu(dlarray(q - 6000,"SSCB")))));
end
Xstar=data(:,sind(1:k));
ratio=zeros(nClass,k);
for i=1:nClass
Y=pdist(Xstar,'correlation');
Z=linkage(Y,"weighted");
labelnew=cluster(Z,'maxclust',i);
for j=1:k
[~,tbl]=anova1(Xstar(:,j),labelnew,'off');
ratio(i,j)=tbl{2,2}/(tbl{4,2});
end
end
ratiostar=sum(ratio,2);
ratiohat=zeros(nClass-2,1);
for o=2:(nClass-1)
ratiohat(o,1)=abs(ratiostar(o+1)-ratiostar(o))/(abs(ratiostar(o)-ratiostar(o-1)+eps));
end
[~,kpre]=min(ratiohat(2:end,1));
kpre=kpre+1;