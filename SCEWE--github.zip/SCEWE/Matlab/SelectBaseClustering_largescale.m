function poolsget=SelectBaseClustering_largescale(dataname,pools,gamma,tau)
%Select base clustering
if strcmp(dataname,'Baronh')
    poolsget = pools;
else
    mu=1e-3;
    s=cell(1,51);
    S=cell(1,51);
    w=cell(1,51);
    [s{1},S{1}]=WeightingCAMatrix(pools,gamma);
    for i=1:1
    w{i}=GeneratingWeights(pools,S{i},tau,0);
    [s{i+1},S{i+1}]=WeightingCAMatrix(pools,gamma,s{i},w{i});
    if norm(S{i+1}-S{i},'fro')/norm(S{i},'fro')<mu
    break
    end
    end
    S(cellfun(@isempty,S))=[];
    w(cellfun(@isempty,w))=[];
    W=sum(cell2mat(w(end)));
    [~,index1]=sort(W,'descend');
    poolsget=pools(:,index1(1:5));
end


