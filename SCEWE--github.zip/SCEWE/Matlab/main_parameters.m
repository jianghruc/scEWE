function [ARI,NMI]=main_parameters(dataname,rawdata,highorder,gamma,sigma1,sigma2)
addpath('./RawData')
addpath('./Matlab')
%Load data
%dataname=char(dataname);
%rawdata=load([dataname,'.csv']);
data=rawdata(1:(end-1),:)';
[n,q]=size(data);
gt=rawdata(end,:);
tic
%Determine the clustering number
kpre=DetermineNumber(data);
%Load base clustering results
addpath('./BCResults')
pools=load(['BCResults_',dataname,'.csv']);
pools=pools(:,1:end-1);
%If highorder
if highorder == 1
    %self-adapt determine lambda
    [lambda,poolsget]=DetermineLambda(data,kpre,pools,highorder);
    %Set parameters
    mu=1e-3;
    if n>=400
    tau=floor(n*(2000+extractdata(relu(dlarray(q-15000,"SSCB"))))/(3600*(kpre+1)));
    else
    tau=floor(n*(2000+extractdata(relu(dlarray(q-15000,"SSCB"))))/(10000*(kpre+1)));
    end
    if exist('gamma','var')==0
    gamma=0.5;
    end
    %Perform ensemble and get the consensus matrix
    s=cell(1,51);
    S=cell(1,51);
    w=cell(1,51);
    [s{1},S{1}]=WeightingCAMatrix(poolsget,gamma);
    for i=1:50
    w{i}=GeneratingWeights(poolsget,S{i},tau,highorder,lambda);
    [s{i+1},S{i+1}]=WeightingCAMatrix(poolsget,gamma,s{i},w{i});
    if norm(S{i+1}-S{i},'fro')/norm(S{i},'fro')<mu
    break
    end
    end
    S(cellfun(@isempty,S))=[];
    %Spectral ensemble clustering
    label=SpectralEnsemble(cell2mat(S(end)),kpre,1000,100);
    ARI=ari(gt,label);
    NMI=nmi(gt,label);
    %Show reults
    disp('#############Scores#############')
    disp(['True cluster number: ',num2str(max(gt))])
    disp(['Predict cluster number: ',num2str(kpre)])
    disp(['ARI: ',num2str(ARI)])
    disp(['NMI: ',num2str(NMI)])
    save(['.\Enresults\EnResult_',dataname,'.mat'],'label');

elseif highorder == 0
    %Select base clustering
    mu=1e-3;
    if n>=400
    tau=floor(n*(2000+extractdata(relu(dlarray(q-15000,"SSCB"))))/(3600*(kpre+1)));
    else
    tau=floor(n*(2000+extractdata(relu(dlarray(q-15000,"SSCB"))))/(10000*(kpre+1)));
    end
    if exist('gamma','var')==0
    gamma=0.5;
    end
    poolsget=pools;
    %Perform ensemble and get the consensus matrix
    s=cell(1,51);
    S=cell(1,51);
    w=cell(1,51);
    [s{1},S{1}]=WeightingCAMatrix(poolsget,gamma);
    for i=1:50
    w{i}=GeneratingWeights(poolsget,S{i},tau,highorder);
    [s{i+1},S{i+1}]=WeightingCAMatrix(poolsget,gamma,s{i},w{i});
    if norm(S{i+1}-S{i},'fro')/norm(S{i},'fro')<mu
    break
    end
    end
    S(cellfun(@isempty,S))=[];
    %Spectral ensemble clustering
    label=SpectralEnsemble(cell2mat(S(end)),kpre,sigma1,sigma2);
    ARI=ari(gt,label);
    NMI=nmi(gt,label);
    %Show reults
    disp('#############Scores#############')
    disp(['True cluster number: ',num2str(max(gt))])
    disp(['Predict cluster number: ',num2str(kpre)])
    disp(['ARI: ',num2str(ARI)])
    disp(['NMI: ',num2str(NMI)])
    save(['.\Enresults\EnResult_',dataname,'.mat'],'label');
else
    disp("Highorder must be 0 or 1")
end
toc